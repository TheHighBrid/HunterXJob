---
name: evaluate-ai-image-realism
description: Evaluate one or more AI-generated or AI-edited images for photographic realism, real-world credibility, and posting quality. Use for image critiques, realism scores, image rankings, selecting which image to post, diagnosing AI tells, comparing iterations, or recommending precise edits that make fashion, product, portrait, lifestyle, editorial, or iPhone-style imagery more convincing.
---

# Evaluate AI Image Realism

Judge what is actually visible. Separate objective defects from taste, avoid invented flaws, and allow the conclusion that no material issue is visible.

## Inspect the evidence

1. View every supplied image at the highest useful resolution. If an image is unavailable, do not imply it was inspected.
2. Identify the intended image type from the request and visual evidence: editorial, candid/iPhone, ecommerce, product, portrait, flash realism, or another format.
3. Evaluate the image against that intended format. Do not penalize deliberate grain, flash falloff, motion, or stylization merely for being imperfect.
4. For multiple images, assign stable labels from the displayed order and confirm that comparisons refer to the correct image.

## Run the realism pass

Inspect these areas before forming a verdict:

- Anatomy: hands, fingers, eyes, teeth, ears, limbs, joints, posture, body proportions, and contact between body parts.
- Identity and continuity: face, body, age, skin tone, hair, garment, logo, and subject consistency across images.
- Clothing and materials: seams, closures, hems, folds, tension, drape, thickness, texture, tailoring, garment-body interaction, and fabric-specific response to light.
- Light and optics: source direction, shadow shape, reflections, exposure, flash behavior, depth of field, lens distortion, grain, chromatic aberration, and edge sharpness.
- Geometry and physics: perspective, scale, object boundaries, weight, gravity, contact points, occlusion, repeated structures, and background architecture.
- Generation artifacts: warped details, fused objects, duplicated patterns, incoherent text, plastic skin, waxy fabric, excessive symmetry, haloing, oversmoothing, and mismatched resolution.

Use a severity hierarchy:

- Critical: instantly exposes the image as artificial or breaks the subject/product.
- Major: noticeable at normal viewing size and materially weakens credibility.
- Minor: visible mainly on inspection and unlikely to stop a post.
- Cosmetic: preference-level refinement, not a realism defect.

## Score three distinct outcomes

Score each from 0 to 100. Do not inflate weak images or punish strong images to manufacture differentiation.

- Realism: technical photographic believability, anatomy, materials, lighting, optics, geometry, and absence of AI artifacts.
- Credibility: whether the complete scene could plausibly exist and be captured as presented, including pose, styling, environment, narrative, and physical coherence.
- Posting quality: whether the image is strong enough to publish for its intended platform or brand, considering composition, clarity, visual impact, crop, product communication, and detectable risk.

Calculate an overall score only when useful:

`overall = realism × 0.45 + credibility × 0.35 + posting quality × 0.20`

Interpretation:

- 95–100: exceptionally convincing; publish-ready with no meaningful concern.
- 90–94: highly convincing; minor inspection-level issues.
- 85–89: strong and postable; a few visible weaknesses.
- 75–84: usable with reservations; editing would materially help.
- 60–74: visibly synthetic or inconsistent.
- Below 60: major failures dominate.

Treat 90+ as earned. A polished or cinematic finish is not automatically realism.

## Select and rank

For comparisons:

1. Choose one clear winner unless the evidence genuinely produces a tie.
2. Rank all images from strongest to weakest.
3. Explain why the winner succeeds relative to the closest alternative.
4. Identify the safest image to post, which may differ from the most visually dramatic image.
5. Keep scoring internally consistent: the ranking must agree with the scores and stated defects.

## Recommend edits

Prioritize the smallest changes with the largest credibility gain. Give specific, localized directions such as “reduce the waxy highlight on the forehead” or “restore natural compression folds at the bent elbow.” Preserve the subject's identity, body, clothing design, logo, framing, and background unless the user asks to change them.

Never use vague filler such as “make it more realistic” without naming the visual cause and desired correction.

## Present the review

For one image, use this compact structure:

1. Verdict and post/no-post recommendation.
2. Realism, credibility, and posting-quality scores.
3. Strongest convincing elements.
4. Visible issues ordered by severity.
5. Two or three highest-impact edits.

For multiple images, lead with the winner, then give a ranked table with the three scores and concise evidence. Follow with the decisive comparison and editing priorities.

Use calibrated language:

- State observed facts directly.
- Mark uncertain readings as possible, subtle, or unverified.
- Distinguish an objective realism defect from a subjective styling preference.
- Never claim invisible details, hidden metadata, camera hardware, or generation method as verified.

## Example output style

> **Verdict:** Strong and postable, but the face and jacket still look slightly overprocessed at close range.
>
> **Scores:** Realism 88/100 · Credibility 90/100 · Posting quality 91/100
>
> The natural stance, coherent window light, and believable full-body framing carry the image. The main weakness is the overly smooth facial texture, followed by slightly rigid jacket folds near the pocket hand. I would post it after restoring subtle skin texture and adding compression folds where the wrist enters the pocket.

Keep the reasoning concrete, decisive, and proportionate to the evidence.
