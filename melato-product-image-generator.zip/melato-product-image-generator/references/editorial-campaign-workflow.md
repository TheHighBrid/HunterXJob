# Editorial Campaign Mode

## Goal

Create realistic, convincing, creatively directed Melato campaign imagery in which the apparel remains exact and the photography carries an intelligent visual idea. Interpret supplied mood, vibe, product, model, decor, location, era, camera, and style references as one coherent art direction.

## Creative direction order

1. Follow the user’s explicit mood, story, location, styling, casting, and destination.
2. Preserve attached product and model references exactly where requested.
3. When the direction is incomplete, choose the strongest visual language based on the garment’s design, material, color, collection, and intended use.
4. When no stronger product-led direction emerges, use grounded cinematic realism: authentic locations, natural texture, restrained light, subtle imperfection, quiet confidence, and a premium but lived-in atmosphere.

Use Flash Realism when requested or when it is clearly the strongest product-led choice: darker ambient environments, direct on-camera flash, transitional locations, mid-movement energy, and deliberate posing. Do not apply it automatically to every campaign.

Do not imitate a living artist or photographer’s exact style. Translate references into high-level visual traits such as lighting, palette, framing, era, texture, pace, or atmosphere.

## Default six-image narrative

When the user does not state an image count, generate six separate images:

1. **Wide Hero**
   - Establish the campaign world, product, location, and central visual idea.
2. **Full-Body I**
   - Present the complete silhouette clearly in a strong product-led pose.
3. **Full-Body II**
   - Add a distinct angle, action, or narrative beat while preserving outfit continuity.
4. **Lifestyle or Movement I**
   - Show a believable interaction, transition, gesture, or environmental action.
5. **Lifestyle or Movement II**
   - Deepen the story without repeating the previous composition.
6. **Tactile Close-Up**
   - Focus on fabric, construction, branding, hardware, styling interaction, or an emotionally useful detail.

Keep all six frames within one campaign world. Avoid purposeless groups, duplicate compositions, and cloned versions of the same person.

## Formats

Choose aspect ratios based on the named destination:

- Website hero: favor a wide hero with safe negative space for interface copy.
- Social feed: favor 4:5 portrait framing with strong mobile readability.
- Story or reel cover: favor 9:16 vertical composition with protected focal areas.
- Lookbook: choose a coherent mix that supports pacing and garment visibility.

If no destination is provided, generate the Wide Hero in 16:9 and the remaining five images in 4:5. The images must remain separate files.

## Product and model fidelity

- Preserve every supplied garment’s colors, panels, seams, trims, proportions, closures, hardware, labels, embroidery, logos, and graphics.
- Keep the garment readable in lighting and pose. Mood must not erase the product.
- Keep the same model’s face, body, age presentation, skin tone, hair, and defining features across recurring frames unless the user requests a change.
- Preserve realistic garment fit and contact with the body. Do not fuse hands, straps, sleeves, hair, or props into the clothing.
- Maintain physical continuity across frames: same product, colorway, model, styling, location logic, time of day, and camera language unless the story intentionally transitions.

If no model is supplied or described, cast autonomously for the garment and concept. Choose credible, distinctive people rather than generic synthetic perfection. Avoid plastic skin, impossible anatomy, over-retouching, and stereotyped casting.

## Realism and photographic credibility

- Use plausible camera perspective, lens behavior, exposure, depth of field, and motion.
- Keep hands, limbs, faces, teeth, hair, and garment-body contact anatomically credible.
- Make shadows, reflections, footprints, weather, fabric motion, and prop interaction obey the same physical scene.
- Add natural skin texture, textile texture, slight lens character, subtle grain, and restrained imperfections when appropriate.
- Avoid oversaturation, plastic lighting, excessive symmetry, cinematic blur everywhere, or a polished AI sheen.
- For an explicitly requested iPhone-realism treatment, use ordinary smartphone depth, restrained processing, believable sharpness, and no artificial background blur unless requested.

## Messaging and wit

Build the campaign around one simple, intelligent visual premise. Express the message primarily through setting, action, juxtaposition, timing, prop choice, composition, or a recurring visual motif.

After the images, provide:

- One concise campaign title
- One optional short caption only when it adds value

Keep this copy outside the generated images. Do not place typography, slogans, or graphic overlays inside an image unless the user explicitly requests them. Do not let a joke cheapen the garment or make the campaign feel like an advertisement template.

## Editorial failure conditions

Regenerate an affected frame if it contains:

- Any change to product identity or Melato branding
- Inconsistent garment construction or model identity across the set
- Implausible anatomy, physics, contact, lighting, or reflections
- Generic luxury clichés without a concept
- A product obscured beyond usefulness
- Repeated compositions or purposeless extra people
- Fake text, accidental typography, or random logos
- A collage, grid, contact sheet, or multiple frames inside one image
